@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install-wizard.ps1"
if errorlevel 1 (
  echo.
  echo Installer exited with an error.
  pause
)
