Dim shell, gameExe, dataPath, configPath, command
Set shell = CreateObject("WScript.Shell")
gameExe = "D:\OpenGOAL\versions\official\v0.3.3\gk.exe"
dataPath = "D:\OpenGOAL\active\jak2\data"
configPath = "D:\OpenGOAL\active\jak2\data\_mod_config\haven-city-air-support"
shell.CurrentDirectory = "D:\OpenGOAL\versions\official\v0.3.3"
command = Chr(34) & gameExe & Chr(34) & " -g jak2 --proj-path " & Chr(34) & dataPath & Chr(34) & " --config-path " & Chr(34) & configPath & Chr(34) & " -- -boot -fakeiso"
shell.Run command, 0, False