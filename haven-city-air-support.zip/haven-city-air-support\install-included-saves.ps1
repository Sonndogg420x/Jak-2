param(
  [switch]$SelfTest
)

$ErrorActionPreference = "Stop"

$DisplayName = "Haven City Air Support Save Installer"
$ModName = "haven-city-air-support"
$SaveFolderName = "BASCUS-97265AYBABTU!"
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$ScriptRoot = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

function Show-Info {
  param([string]$Message)
  [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "OK", "Information") | Out-Null
}

function Show-Warning {
  param([string]$Message)
  [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "OK", "Warning") | Out-Null
}

function Show-Error {
  param([string]$Message)
  [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "OK", "Error") | Out-Null
}

function Confirm-Install {
  param([string]$Message)
  $result = [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "OKCancel", "Warning")
  return ($result -eq [System.Windows.Forms.DialogResult]::OK)
}

function Ask-YesNo {
  param([string]$Message)
  $result = [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "YesNo", "Question")
  return ($result -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Normalize-DirectoryPath {
  param([string]$Path)
  if (-not $Path) {
    return $null
  }
  return [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
}

function Get-BundledSaveFolder {
  $path = Join-Path $ScriptRoot "personal-saves\OpenGOAL\jak2\saves\$SaveFolderName"
  if (-not (Test-Path -LiteralPath $path)) {
    throw "Bundled save folder was not found: $path"
  }
  return $path
}

function Test-Jak2DataPath {
  param([string]$DataPath)

  $DataPath = Normalize-DirectoryPath $DataPath
  if (-not $DataPath) {
    return $false
  }

  $required = @(
    "goal_src\jak2\levels\city\traffic\traffic-manager.gc",
    "goal_src\jak2\levels\city\traffic\vehicle\vehicle-guard.gc",
    "goal_src\jak2\dgos\lwideb.gd"
  )

  foreach ($relative in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $DataPath $relative))) {
      return $false
    }
  }
  return $true
}

function Resolve-Jak2DataPath {
  param([string]$SelectedPath)

  $selected = Normalize-DirectoryPath $SelectedPath
  if (-not $selected) {
    return $null
  }

  $candidatePaths = New-Object System.Collections.Generic.List[string]
  foreach ($candidate in @(
      $selected,
      (Join-Path $selected "data"),
      (Join-Path $selected "jak2\data"),
      (Join-Path $selected "active\jak2\data"),
      (Join-Path $selected "features\jak2\mods\JakMods\$ModName\data")
    )) {
    if ($candidate) {
      $candidatePaths.Add($candidate)
    }
  }

  foreach ($candidate in $candidatePaths.ToArray()) {
    if (Test-Jak2DataPath $candidate) {
      return (Normalize-DirectoryPath $candidate)
    }
  }

  return $null
}

function Select-OpenGoalFolder {
  $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description = "Optional: choose the OpenGOAL folder if you want to overwrite the mod VBS launcher's isolated save folder too."
  $dialog.ShowNewFolderButton = $false
  $result = $dialog.ShowDialog()
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    return $dialog.SelectedPath
  }
  return $null
}

function Copy-IncludedSaveSet {
  param(
    [string]$TargetSaveFolder,
    [string]$Label
  )

  $source = Get-BundledSaveFolder
  $target = Normalize-DirectoryPath $TargetSaveFolder
  if (-not $target) {
    throw "Invalid target save folder for $Label."
  }

  $savesRoot = Split-Path -Parent $target
  $jak2Root = Split-Path -Parent $savesRoot
  $labelSafe = ($Label -replace '[^A-Za-z0-9_.-]', '-')
  $backupPath = Join-Path $jak2Root "save-backups\$ModName\$Timestamp\$labelSafe\$SaveFolderName"

  if (Test-Path -LiteralPath $target) {
    $backupParent = Split-Path -Parent $backupPath
    New-Item -ItemType Directory -Force -Path $backupParent | Out-Null
    Copy-Item -LiteralPath $target -Destination $backupPath -Recurse -Force
  }

  New-Item -ItemType Directory -Force -Path $target | Out-Null
  Copy-Item -Path (Join-Path $source "*") -Destination $target -Recurse -Force

  $bankCount = Get-ChildItem -LiteralPath $target -File -Filter "bank*.bin" | Measure-Object | Select-Object -ExpandProperty Count
  if ($bankCount -lt 8) {
    throw "Expected 8 save bank files at $target, but found $bankCount."
  }

  return [PSCustomObject]@{
    Label = $Label
    Target = $target
    Backup = if (Test-Path -LiteralPath $backupPath) { $backupPath } else { "No previous save folder was present." }
    Banks = $bankCount
  }
}

function Install-IncludedSaves {
  if (-not $env:APPDATA) {
    throw "APPDATA was not available, so the normal OpenGOAL save folder could not be found."
  }

  $source = Get-BundledSaveFolder
  $defaultTarget = Join-Path $env:APPDATA "OpenGOAL\jak2\saves\$SaveFolderName"

  $message = @"
This will overwrite the Jak II OpenGOAL save banks at:

$defaultTarget

A timestamped backup will be created first if saves already exist there.

Bundled save source:
$source

Game 3, the third save slot, is the late-game Haven City invasion state save.
"@

  if (-not (Confirm-Install $message)) {
    return
  }

  $targets = New-Object System.Collections.Generic.List[object]
  $targets.Add([PSCustomObject]@{
      Label = "normal OpenGOAL profile"
      Path = $defaultTarget
    })

  $modConfigMessage = "Do you also want to select your OpenGOAL folder and overwrite the mod VBS launcher's isolated save folder? Choose Yes if you launch the mod from Launch Haven City Air Support.vbs."
  if (Ask-YesNo $modConfigMessage) {
    $selected = Select-OpenGoalFolder
    if ($selected) {
      $dataPath = Resolve-Jak2DataPath $selected
      if ($dataPath) {
        $modTarget = Join-Path $dataPath "_mod_config\$ModName\OpenGOAL\jak2\saves\$SaveFolderName"
        $targets.Add([PSCustomObject]@{
            Label = "mod VBS launcher config"
            Path = $modTarget
          })
      }
      else {
        Show-Warning "Could not find a valid Jak II data folder under the selected OpenGOAL path. The normal OpenGOAL profile saves will still be installed."
      }
    }
  }

  $results = New-Object System.Collections.Generic.List[object]
  foreach ($target in $targets.ToArray()) {
    $results.Add((Copy-IncludedSaveSet $target.Path $target.Label))
  }

  $summary = New-Object System.Text.StringBuilder
  [void]$summary.AppendLine("Included Jak II saves were installed successfully.")
  [void]$summary.AppendLine("")
  [void]$summary.AppendLine("Installed targets:")
  foreach ($result in $results.ToArray()) {
    [void]$summary.AppendLine("")
    [void]$summary.AppendLine("$($result.Label):")
    [void]$summary.AppendLine($result.Target)
    [void]$summary.AppendLine("Bank files: $($result.Banks)")
    [void]$summary.AppendLine("Backup:")
    [void]$summary.AppendLine($result.Backup)
  }
  [void]$summary.AppendLine("")
  [void]$summary.AppendLine("Load Game 3, the third save slot, for the Haven City invasion state.")

  Show-Info $summary.ToString()
}

if ($SelfTest) {
  Get-BundledSaveFolder | Out-Null
  Write-Output "Save installer self-test passed."
  exit 0
}

try {
  Install-IncludedSaves
}
catch {
  Show-Error $_.Exception.Message
  throw
}
