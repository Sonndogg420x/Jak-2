param(
  [switch]$SelfTest,
  [string]$PatchOnlyDataPath,
  [string]$ResolveOnlyPath,
  [string]$RunInstallPath,
  [string]$StatusFile
)

$ErrorActionPreference = "Stop"

$ModName = "haven-city-air-support"
$DisplayName = "Haven City Air Support"
$Version = "0.1.0"
$InstallerScriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

function Show-Info {
  param([string]$Message)
  [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "OK", "Information") | Out-Null
}

function Show-SuccessBox {
  param([string]$Message)
  [System.Windows.Forms.MessageBox]::Show($Message, "Installation Complete", "OK", "Information") | Out-Null
}

function Show-ErrorBox {
  param([string]$Message)
  [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "OK", "Error") | Out-Null
}

function Confirm-Action {
  param([string]$Message)
  $result = [System.Windows.Forms.MessageBox]::Show($Message, $DisplayName, "OKCancel", "Question")
  return ($result -eq [System.Windows.Forms.DialogResult]::OK)
}

function Read-TextFile {
  param([string]$Path)
  return ([System.IO.File]::ReadAllText($Path) -replace "`r`n", "`n")
}

function Write-TextFile {
  param(
    [string]$Path,
    [string]$Text
  )
  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Text, $encoding)
}

function Write-InstallStatus {
  param(
    [string]$Path,
    [string]$State,
    [string]$Message,
    [hashtable]$Details
  )

  if (-not $Path) {
    return
  }

  $lines = New-Object System.Collections.Generic.List[string]
  $lines.Add($State)
  $lines.Add($Message)
  if ($Details) {
    foreach ($key in ($Details.Keys | Sort-Object)) {
      $lines.Add("$key=$($Details[$key])")
    }
  }

  $encoding = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllLines($Path, $lines.ToArray(), $encoding)
}

function Read-InstallStatus {
  param([string]$Path)

  if (-not $Path -or -not (Test-Path -LiteralPath $Path)) {
    return $null
  }

  $lines = [System.IO.File]::ReadAllLines($Path)
  if ($lines.Count -lt 2) {
    return $null
  }

  $details = @{}
  for ($i = 2; $i -lt $lines.Count; $i++) {
    $split = $lines[$i].IndexOf("=")
    if ($split -gt 0) {
      $details[$lines[$i].Substring(0, $split)] = $lines[$i].Substring($split + 1)
    }
  }

  return [PSCustomObject]@{
    State = $lines[0]
    Message = $lines[1]
    Details = $details
  }
}

function Quote-ProcessArgument {
  param([string]$Value)
  return '"' + ($Value -replace '"', '\"') + '"'
}

function Normalize-DirectoryPath {
  param([string]$Path)

  if ([string]::IsNullOrWhiteSpace($Path)) {
    return $null
  }

  $expanded = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
  if ($expanded -match '^[A-Za-z]:$') {
    $expanded = "$expanded\"
  }

  if (-not (Test-Path -LiteralPath $expanded -PathType Container)) {
    return $null
  }

  return (Resolve-Path -LiteralPath $expanded).ProviderPath
}

function Get-ParentDirectory {
  param([string]$Path)

  $normalized = Normalize-DirectoryPath $Path
  if (-not $normalized) {
    return $null
  }

  $root = [System.IO.Path]::GetPathRoot($normalized)
  $full = [System.IO.Path]::GetFullPath($normalized).TrimEnd('\')
  $rootFull = [System.IO.Path]::GetFullPath($root).TrimEnd('\')
  if ($full -ieq $rootFull) {
    return $null
  }

  $parent = [System.IO.Directory]::GetParent($full)
  if ($parent) {
    return $parent.FullName
  }
  return $null
}

function Test-Jak2DataPath {
  param([string]$DataPath)
  $DataPath = Normalize-DirectoryPath $DataPath
  if (-not $DataPath) {
    return $false
  }
  $required = @(
    "goal_src\jak2\levels\city\traffic\vehicle\vehicle-guard.gc",
    "goal_src\jak2\levels\city\traffic\traffic-manager.gc",
    "goal_src\jak2\levels\city\ctywide-obs.gc",
    "goal_src\jak2\dgos\lwideb.gd"
  )
  foreach ($relative in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $DataPath $relative))) {
      return $false
    }
  }
  return $true
}

function Find-Goalc {
  param(
    [string]$SelectedPath,
    [string]$DataPath
  )

  $candidateFiles = New-Object System.Collections.Generic.List[string]
  $pathsToWalk = New-Object System.Collections.Generic.List[string]
  foreach ($path in @($SelectedPath, $DataPath, (Get-ParentDirectory $DataPath))) {
    $normalized = Normalize-DirectoryPath $path
    if ($normalized) {
      $pathsToWalk.Add($normalized)
    }
  }

  foreach ($start in @($pathsToWalk.ToArray())) {
    $current = $start
    for ($i = 0; $i -lt 7 -and $current; $i++) {
      $direct = Join-Path $current "goalc.exe"
      if (Test-Path -LiteralPath $direct) {
        $candidateFiles.Add($direct)
      }

      $versionsRoot = Join-Path $current "versions\official"
      if (Test-Path -LiteralPath $versionsRoot) {
        Get-ChildItem -LiteralPath $versionsRoot -Directory -ErrorAction SilentlyContinue |
          Sort-Object Name -Descending |
          ForEach-Object {
            $versioned = Join-Path $_.FullName "goalc.exe"
            if (Test-Path -LiteralPath $versioned) {
              $candidateFiles.Add($versioned)
            }
          }
      }

      $parent = Get-ParentDirectory $current
      if (-not $parent -or $parent -eq $current) {
        break
      }
      $current = $parent
    }
  }

  $unique = @($candidateFiles.ToArray() | Select-Object -Unique)
  if ($unique.Count -gt 0) {
    return $unique[0]
  }

  return $null
}

function Get-SiblingGk {
  param([string]$CompilerPath)

  if (-not $CompilerPath) {
    return $null
  }
  $compilerDir = Normalize-DirectoryPath (Split-Path -Parent $CompilerPath)
  if (-not $compilerDir) {
    return $null
  }
  $candidate = Join-Path $compilerDir "gk.exe"
  if (Test-Path -LiteralPath $candidate) {
    return (Resolve-Path -LiteralPath $candidate).ProviderPath
  }
  return $null
}

function Find-OpenGoalRoot {
  param(
    [string]$SelectedPath,
    [string]$DataPath
  )

  $pathsToWalk = New-Object System.Collections.Generic.List[string]
  foreach ($path in @($SelectedPath, $DataPath)) {
    $normalized = Normalize-DirectoryPath $path
    while ($normalized) {
      $pathsToWalk.Add($normalized)
      $normalized = Get-ParentDirectory $normalized
    }
  }

  foreach ($candidate in @($pathsToWalk.ToArray() | Select-Object -Unique)) {
    $activeData = Join-Path $candidate "active\jak2\data"
    $modsRoot = Join-Path $candidate "features\jak2\mods\JakMods"
    $versionsRoot = Join-Path $candidate "versions\official"
    if ((Test-Path -LiteralPath $activeData -PathType Container) -and
        ((Test-Path -LiteralPath $modsRoot -PathType Container) -or
         (Test-Path -LiteralPath $versionsRoot -PathType Container) -or
         (Test-Path -LiteralPath (Join-Path $candidate "OpenGOAL-Launcher.exe")))) {
      return $candidate
    }
  }

  return $null
}

function Resolve-InstallTarget {
  param([string]$SelectedPath)

  if ([string]::IsNullOrWhiteSpace($SelectedPath)) {
    throw "Choose your OpenGOAL or Jak II folder first."
  }
  $selected = Normalize-DirectoryPath $SelectedPath
  if (-not $selected) {
    throw "The selected folder does not exist."
  }

  $candidateDataPaths = New-Object System.Collections.Generic.List[string]
  $candidateDataPaths.Add($selected)
  $candidateDataPaths.Add((Join-Path $selected "data"))
  $candidateDataPaths.Add((Join-Path $selected "active\jak2\data"))
  $candidateDataPaths.Add((Join-Path $selected "features\jak2\mods\JakMods\haven-city-air-support\data"))

  foreach ($candidate in $candidateDataPaths.ToArray() | Select-Object -Unique) {
    if (Test-Jak2DataPath $candidate) {
      $dataPath = Normalize-DirectoryPath $candidate
      $compiler = Find-Goalc $selected $dataPath
      if (-not $compiler) {
        throw "Found Jak II data, but could not find goalc.exe. Choose the OpenGOAL folder that contains versions\official, or choose a mod/build folder that contains goalc.exe."
      }

      return [PSCustomObject]@{
        SelectedPath = $selected
        DataPath = $dataPath
        CompilerPath = (Resolve-Path -LiteralPath $compiler).ProviderPath
        GamePath = Get-SiblingGk $compiler
        OpenGoalRoot = Find-OpenGoalRoot $selected $dataPath
      }
    }
  }

  throw "Could not find a valid OpenGOAL Jak II data folder. Choose the OpenGOAL folder that contains OpenGOAL-Launcher.exe, or choose active\jak2\data."
}

function Backup-File {
  param(
    [string]$SourceRoot,
    [string]$BackupRoot,
    [string]$RelativePath
  )

  $source = Join-Path $SourceRoot $RelativePath
  if (Test-Path -LiteralPath $source) {
    $destination = Join-Path $BackupRoot $RelativePath
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Force
  }
}

function Patch-VehicleGuard {
  param([string]$Path)

  $text = Read-TextFile $Path
  $changed = $false

  $supportBlock = @'
(defun vehicle-guard-support-fire ((this vehicle-guard))
  (when (and (logtest? (-> this controller traffic alert-state flags) (traffic-alert-flag guard-multi-focus))
             (logtest? (rigid-body-object-flag ai-driving) (-> this flags))
             (not (logtest? (rigid-body-object-flag player-driving) (-> this flags)))
             (not (focus-test? this dead inactive))
             )
    (let ((s5-0 (find-closest-to-with-collide-lists
                  (-> this controller traffic)
                  this
                  (collide-spec enemy hit-by-player-list hit-by-others-list)
                  ))
          )
      (when s5-0
        (let ((s4-0 (new 'stack-no-clear 'vector)))
          (set! (-> s4-0 quad) (-> (get-trans s5-0 3) quad))
          (+! (-> s4-0 y) 4096.0)
          (when (and (< (vector-vector-xz-distance (-> this root trans) s4-0) 184320.0)
                     (vehicle-los-clear? s4-0 (-> this root trans))
                     )
            (turret-control-method-9 (-> this turret) this s4-0 (get-transv s5-0))
            (when (and (logtest? (-> this turret flags) (turret-flag should-shoot))
                       (time-elapsed? (-> this turret shoot-time) (seconds 0.35))
                       )
              (vehicle-guard-method-155 this s4-0 (get-transv s5-0))
              (set-time! (-> this turret shoot-time))
              )
            )
          )
        )
      )
    )
  0
  (none)
  )

(defun vehicle-guard-support-chase ((this vehicle-guard))
  (when (and (logtest? (-> this controller traffic alert-state flags) (traffic-alert-flag guard-multi-focus))
             (logtest? (rigid-body-object-flag ai-driving) (-> this flags))
             (not (logtest? (rigid-body-object-flag player-driving in-pursuit) (-> this flags)))
             (not (focus-test? this dead inactive))
             )
    (logclear! (-> this controller flags) (vehicle-controller-flag ignore-others direct-mode no-slowing-for-turns))
    (let ((s5-0 (find-closest-to-with-collide-lists
                  (-> this controller traffic)
                  this
                  (collide-spec enemy hit-by-player-list hit-by-others-list)
                  ))
          )
      (when s5-0
        (let ((s4-0 (new 'stack-no-clear 'vector))
              (s3-0 (new 'stack-no-clear 'vector))
              )
          (set! (-> s4-0 quad) (-> (get-trans s5-0 3) quad))
          (vector+float*! s4-0 s4-0 (get-transv s5-0) 0.45)
          (set! (-> s4-0 y) (fmax (-> this flight-level) (+ (-> s4-0 y) 24576.0)))
          (let ((f30-0 (vector-vector-xz-distance (-> this root trans) s4-0)))
            (when (and (< f30-0 430080.0) (< 8192.0 f30-0))
              (vector-! s3-0 s4-0 (-> this root trans))
              (set! (-> s3-0 y) 0.0)
              (vector-normalize! s3-0 1.0)
              (vector-float*! s3-0 s3-0 (* 1.35 (-> this info max-xz-speed)))
              (vehicle-controller-method-19 (-> this controller) (-> this root trans) #x43cccccd s4-0 s3-0)
              (set! (-> this controller target-speed) (* 1.35 (-> this info max-xz-speed)))
              (logior! (-> this controller flags) (vehicle-controller-flag ignore-others direct-mode no-slowing-for-turns))
              )
            )
          )
        )
      )
    )
  0
  (none)
  )

'@

  $playerAutoAimBlock = @'
(defun vehicle-guard-player-auto-target ((this vehicle-guard) (arg0 vector) (arg1 vector))
  (let ((s5-0 (find-closest-to-with-collide-lists
                (-> this controller traffic)
                this
                (collide-spec enemy hit-by-player-list hit-by-others-list)
                ))
        )
    (when s5-0
      (let ((s4-0 (new 'stack-no-clear 'vector)))
        (set! (-> s4-0 quad) (-> (get-trans s5-0 3) quad))
        (+! (-> s4-0 y) 4096.0)
        (if (and (< (vector-vector-xz-distance (-> this root trans) s4-0) 286720.0)
                 (vehicle-los-clear? s4-0 (-> this root trans))
                 )
            (begin
              (set! (-> arg0 quad) (-> s4-0 quad))
              (set! (-> arg1 quad) (-> (get-transv s5-0) quad))
              )
            (set! s5-0 (the-as process-focusable #f))
            )
        )
      )
    s5-0
    )
  )

'@

  if ($text -notmatch "vehicle-guard-support-fire") {
    $anchor = "(defmethod vehicle-guard-method-155 ((this vehicle-guard) (arg0 vector) (arg1 vector))"
    if (-not $text.Contains($anchor)) {
      throw "Could not find vehicle support insertion anchor in vehicle-guard.gc."
    }
    $text = $text.Replace($anchor, $supportBlock + "`n" + $anchor)
    $changed = $true
  }

  if ($text -notmatch "vehicle-guard-player-auto-target") {
    $anchor = "(defmethod vehicle-method-94 ((this vehicle-guard))"
    if (-not $text.Contains($anchor)) {
      throw "Could not find player guard vehicle auto-aim insertion anchor in vehicle-guard.gc."
    }
    $text = $text.Replace($anchor, $playerAutoAimBlock + $anchor)
    $changed = $true
  }

  if ($text -notmatch "vehicle-guard-player-auto-target this") {
    $old = @'
      (vector-reset! (-> v1-0 up))
      (set! (-> this turret inaccuracy) 0.0)
      (turret-control-method-9 (-> this turret) this (-> v1-0 rv) (-> v1-0 up))
      )
    (when (cpad-hold? 0 r1)
      (when (time-elapsed? (-> this turret shoot-time) (seconds 0.35))
        (set! (-> this turret owner-handle) (process->handle *target*))
        (turret-control-method-17 (-> this turret) this)
        (set! (-> this turret owner-handle) (the-as handle #f))
        )
      )
'@
    $new = @'
      (vector-reset! (-> v1-0 up))
      (let ((s5-0 (vehicle-guard-player-auto-target this (-> v1-0 rv) (-> v1-0 up))))
        (set! (-> this turret inaccuracy) 0.0)
        (turret-control-method-9 (-> this turret) this (-> v1-0 rv) (-> v1-0 up))
        (when (cpad-hold? 0 r1)
          (when (time-elapsed? (-> this turret shoot-time) (seconds 0.35))
            (set! (-> this turret owner-handle) (process->handle *target*))
            (if (and s5-0 (logtest? (-> this turret flags) (turret-flag should-shoot)))
                (begin
                  (vehicle-guard-method-155 this (-> v1-0 rv) (-> v1-0 up))
                  (set-time! (-> this turret shoot-time))
                  )
                (turret-control-method-17 (-> this turret) this)
                )
            (set! (-> this turret owner-handle) (the-as handle #f))
            )
          )
        )
      )
'@
    if (-not $text.Contains($old)) {
      throw "Could not find player guard vehicle auto-aim replacement anchor in vehicle-guard.gc."
    }
    $text = $text.Replace($old, $new)
    $changed = $true
  }

  $missingPlayerAimClose = "`n        )`n    ((method-of-type vehicle vehicle-method-94) this)"
  if ($text.Contains($missingPlayerAimClose)) {
    $text = $text.Replace(
      $missingPlayerAimClose,
      "`n        )`n      )`n    ((method-of-type vehicle vehicle-method-94) this)"
    )
    $changed = $true
  }

  if ($text -notmatch "vehicle-guard-support-chase self") {
    $old = "    (check-player-get-on self)`n    (vehicle-method-122 self)"
    $new = "    (vehicle-guard-support-chase self)`n    (vehicle-guard-support-fire self)`n    (check-player-get-on self)`n    (vehicle-method-122 self)"
    if (-not $text.Contains($old)) {
      throw "Could not find vehicle support call anchor in vehicle-guard.gc."
    }
    $text = $text.Replace($old, $new)
    $changed = $true
  }

  if ($changed) {
    Write-TextFile $Path $text
  }
}

function Patch-TrafficManager {
  param([string]$Path)

  $text = Read-TextFile $Path
  $changed = $false

  $old = "         (set! (-> gp-0 object-type-info-array 18 level) 'lwideb)`n         (set! (-> gp-0 object-type-info-array 19 level) #f)"
  $new = "         (set! (-> gp-0 object-type-info-array 18 level) 'lwideb)`n         (set! (-> gp-0 object-type-info-array 19 level) 'lwideb)"

  if (-not $text.Contains($new)) {
    if (-not $text.Contains($old)) {
      throw "Could not find Hellcat lwideb traffic anchor in traffic-manager.gc."
    }

    $text = $text.Replace($old, $new)
    $changed = $true
  }

  $capReplacements = @(
    @{
      Old = "    (set! (-> traffic-want-counts 18) 4)"
      New = "    (set! (-> traffic-want-counts 18) 6)"
      Name = "guard-bike"
    },
    @{
      Old = "    (set! (-> traffic-want-counts 19) 3)"
      New = "    (set! (-> traffic-want-counts 19) 6)"
      Name = "hellcat"
    }
  )

  foreach ($cap in $capReplacements) {
    if ($text.Contains($cap.New)) {
      continue
    }
    if (-not $text.Contains($cap.Old)) {
      throw "Could not find $($cap.Name) traffic cap anchor in traffic-manager.gc."
    }
    $text = $text.Replace($cap.Old, $cap.New)
    $changed = $true
  }

  if ($changed) {
    Write-TextFile $Path $text
  }
}

function Patch-Lwideb {
  param([string]$Path)

  $text = Read-TextFile $Path
  if ($text -match '"hellcat-ag.go"') {
    return
  }
  $old = '  "flitter-ag.go"'
  $new = "  `"flitter-ag.go`"`n  `"hellcat-ag.go`""
  if (-not $text.Contains($old)) {
    throw "Could not find hellcat asset insertion anchor in lwideb.gd."
  }

  Write-TextFile $Path ($text.Replace($old, $new))
}

function Patch-CtywideObs {
  param([string]$Path)

  $text = Read-TextFile $Path
  $changed = $false

  $helperBlock = @'
(defun cty-guard-turret-metalhead-target? ((arg0 process-focusable))
  (or (type? arg0 metalhead-grunt)
      (type? arg0 metalhead-predator)
      (type? arg0 metalhead-flitter)
      )
  )

(defun cty-guard-turret-find-metalhead-target ((this cty-guard-turret) (arg0 float))
  (let ((s5-0 (the-as process-focusable #f))
        (f30-0 (square arg0))
        )
    (when *traffic-engine*
      (let ((v1-0 (-> *collide-hit-by-player-list* alive-list next0)))
        *collide-hit-by-player-list*
        (let ((s3-0 (-> v1-0 next0)))
          (while (!= v1-0 (-> *collide-hit-by-player-list* alive-list-end))
            (let ((v1-1 (the-as collide-shape (-> (the-as connection v1-0) param1))))
              (when (logtest? (collide-spec enemy) (-> v1-1 root-prim prim-core collide-as))
                (let ((s2-0 (as-type (-> v1-1 process) process-focusable)))
                  (when (and s2-0
                             (cty-guard-turret-metalhead-target? s2-0)
                             (not (focus-test? s2-0 disable dead inactive))
                             (!= this s2-0)
                             )
                    (let ((f0-0 (vector-vector-xz-distance-squared (-> this root trans) (-> s2-0 root trans))))
                      (when (< f0-0 f30-0)
                        (set! s5-0 s2-0)
                        (set! f30-0 f0-0)
                        )
                      )
                    )
                  )
                )
              )
            (set! v1-0 s3-0)
            *collide-hit-by-player-list*
            (set! s3-0 (-> s3-0 next0))
            )
          )
        )
      (let ((v1-2 (-> *collide-hit-by-others-list* alive-list next0)))
        *collide-hit-by-others-list*
        (let ((s3-1 (-> v1-2 next0)))
          (while (!= v1-2 (-> *collide-hit-by-others-list* alive-list-end))
            (let ((v1-3 (the-as collide-shape (-> (the-as connection v1-2) param1))))
              (when (logtest? (collide-spec enemy) (-> v1-3 root-prim prim-core collide-as))
                (let ((s2-1 (as-type (-> v1-3 process) process-focusable)))
                  (when (and s2-1
                             (cty-guard-turret-metalhead-target? s2-1)
                             (not (focus-test? s2-1 disable dead inactive))
                             (!= this s2-1)
                             )
                    (let ((f0-1 (vector-vector-xz-distance-squared (-> this root trans) (-> s2-1 root trans))))
                      (when (< f0-1 f30-0)
                        (set! s5-0 s2-1)
                        (set! f30-0 f0-1)
                        )
                      )
                    )
                  )
                )
              )
            (set! v1-2 s3-1)
            *collide-hit-by-others-list*
            (set! s3-1 (-> s3-1 next0))
            )
          )
        )
      )
    s5-0
    )
  )

(defun cty-guard-turret-update-support-focus ((this cty-guard-turret) (arg0 float))
  (let ((s5-0 (cty-guard-turret-find-metalhead-target this arg0)))
    (when s5-0
      (try-update-focus (-> this focus) (the-as process-focusable s5-0))
      )
    s5-0
    )
  )

'@

  if ($text -notmatch "cty-guard-turret-metalhead-target") {
    $anchor = "(defstate idle (cty-guard-turret)"
    if (-not $text.Contains($anchor)) {
      throw "Could not find turret helper insertion anchor in ctywide-obs.gc."
    }
    $text = $text.Replace($anchor, $helperBlock + "`n" + $anchor)
    $changed = $true
  }

  $shutdown = @'
    (if (= (level-status *level* 'lwideb) 'active)
        (set! (-> self destroyed) #t)
        )
'@
  $supportUpdate = @'
    ;; Keep city turrets online during the late-game invasion pass.
    (when (and *traffic-engine*
               (>= (the-as uint (get-alert-level *traffic-engine*)) (the-as uint 1))
               (not (-> self destroyed))
               )
      (cty-guard-turret-update-support-focus self 409600.0)
      )
'@

  if ($text -notmatch "Keep city turrets online during the late-game invasion pass") {
    if (-not $text.Contains($shutdown)) {
      throw "Could not find turret lwideb shutdown block in ctywide-obs.gc."
    }
    $text = $text.Replace($shutdown, $supportUpdate)
    $changed = $true
  }

  $pilotOnly = @'
            (if (and (focus-test? (the-as process-focusable gp-2) pilot)
                     (>= (the-as uint (get-alert-level *traffic-engine*)) (the-as uint 1))
                     )
'@
  $pilotOrMetalhead = @'
            (if (and (or (focus-test? (the-as process-focusable gp-2) pilot)
                         (cty-guard-turret-metalhead-target? (the-as process-focusable gp-2))
                         )
                     (>= (the-as uint (get-alert-level *traffic-engine*)) (the-as uint 1))
                     )
'@

  if ($text -notmatch "cty-guard-turret-metalhead-target\? \(the-as process-focusable gp-2\)") {
    if (-not $text.Contains($pilotOnly)) {
      throw "Could not find turret hostile transition anchor in ctywide-obs.gc."
    }
    $text = $text.Replace($pilotOnly, $pilotOrMetalhead)
    $changed = $true
  }

  if ($text -notmatch "cty-guard-turret-update-support-focus self 491520.0") {
    $hostileStart = $text.IndexOf("(defstate hostile (cty-guard-turret)")
    if ($hostileStart -lt 0) {
      throw "Could not find turret hostile state in ctywide-obs.gc."
    }
    $anchor = "      (suspend)`n      (let ((gp-0 (handle->process (-> self focus handle))))"
    $anchorIndex = $text.IndexOf($anchor, $hostileStart)
    if ($anchorIndex -lt 0) {
      throw "Could not find turret hostile refresh anchor in ctywide-obs.gc."
    }
    $refresh = @'
      (suspend)
      (let ((gp-1 (handle->process (-> self focus handle))))
        (when (and *traffic-engine*
                   (>= (the-as uint (get-alert-level *traffic-engine*)) (the-as uint 1))
                   (or (not gp-1)
                       (cty-guard-turret-metalhead-target? (the-as process-focusable gp-1))
                       )
                   )
          (cty-guard-turret-update-support-focus self 491520.0)
          )
        )
      (let ((gp-0 (handle->process (-> self focus handle))))
'@
    $text = $text.Remove($anchorIndex, $anchor.Length).Insert($anchorIndex, $refresh.TrimEnd("`n"))
    $changed = $true
  }

  if ($changed) {
    Write-TextFile $Path $text
  }
}

function Apply-ModPatch {
  param([string]$DataPath)

  Patch-VehicleGuard (Join-Path $DataPath "goal_src\jak2\levels\city\traffic\vehicle\vehicle-guard.gc")
  Patch-TrafficManager (Join-Path $DataPath "goal_src\jak2\levels\city\traffic\traffic-manager.gc")
  Patch-Lwideb (Join-Path $DataPath "goal_src\jak2\dgos\lwideb.gd")
  Patch-CtywideObs (Join-Path $DataPath "goal_src\jak2\levels\city\ctywide-obs.gc")
}

function Invoke-GoalcRebuild {
  param(
    [string]$CompilerPath,
    [string]$DataPath,
    [string]$BackupRoot
  )

  $logPath = Join-Path $BackupRoot "goalc-build.log"
  $compilerDir = Normalize-DirectoryPath (Split-Path -Parent $CompilerPath)
  if (-not $compilerDir) {
    throw "Could not find the compiler folder for $CompilerPath."
  }
  $arguments = @("-g", "jak2", "--proj-path", $DataPath, "-c", "(mi)")

  "Running: $CompilerPath $($arguments -join ' ')" | Set-Content -LiteralPath $logPath -Encoding UTF8
  Push-Location $compilerDir
  try {
    & $CompilerPath @arguments 2>&1 | Tee-Object -FilePath $logPath -Append
    $exitCode = $LASTEXITCODE
  }
  finally {
    Pop-Location
  }

  if ($exitCode -ne 0) {
    throw "goalc rebuild failed with exit code $exitCode. Build log: $logPath"
  }

  return $logPath
}

function Escape-VbsString {
  param([string]$Value)
  return ($Value -replace '"', '""')
}

function Write-VbsLauncher {
  param(
    [string]$GamePath,
    [string]$DataPath,
    [string]$OutputDirectory
  )

  if (-not $GamePath -or -not (Test-Path -LiteralPath $GamePath)) {
    return $null
  }

  if ($OutputDirectory) {
    New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
    $launcherRoot = Normalize-DirectoryPath $OutputDirectory
  }
  else {
    $launcherRoot = $PSScriptRoot
    if (-not $launcherRoot) {
      $launcherRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
    }
  }

  $launcherPath = Join-Path $launcherRoot "Launch Haven City Air Support.vbs"
  $configPath = Join-Path $DataPath "_mod_config\$ModName"
  New-Item -ItemType Directory -Force -Path $configPath | Out-Null

  $gameDir = Normalize-DirectoryPath (Split-Path -Parent $GamePath)
  $game = Escape-VbsString $GamePath
  $data = Escape-VbsString $DataPath
  $config = Escape-VbsString $configPath
  $cwd = Escape-VbsString $gameDir

  $vbs = @"
Dim shell, gameExe, dataPath, configPath, command
Set shell = CreateObject("WScript.Shell")
gameExe = "$game"
dataPath = "$data"
configPath = "$config"
shell.CurrentDirectory = "$cwd"
command = Chr(34) & gameExe & Chr(34) & " -g jak2 --proj-path " & Chr(34) & dataPath & Chr(34) & " --config-path " & Chr(34) & configPath & Chr(34) & " -- -boot -fakeiso"
shell.Run command, 0, False
"@

  Write-TextFile $launcherPath $vbs
  return $launcherPath
}

function Install-VisibleModFolder {
  param(
    [object]$Target,
    [string]$BackupRoot,
    [string]$LogPath
  )

  if (-not $Target.OpenGoalRoot) {
    return $null
  }

  $modsRoot = Join-Path $Target.OpenGoalRoot "features\jak2\mods\JakMods"
  $modRoot = Join-Path $modsRoot $ModName
  New-Item -ItemType Directory -Force -Path $modRoot | Out-Null

  $scriptRoot = $PSScriptRoot
  if (-not $scriptRoot) {
    $scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
  }

  foreach ($name in @("readme.txt", "_metadata.json")) {
    $source = Join-Path $scriptRoot $name
    if (Test-Path -LiteralPath $source) {
      Copy-Item -LiteralPath $source -Destination (Join-Path $modRoot $name) -Force
    }
  }

  $launcher = Write-VbsLauncher $Target.GamePath $Target.DataPath $modRoot
  $cmd = @'
@echo off
setlocal
wscript.exe "%~dp0Launch Haven City Air Support.vbs"
'@
  Write-TextFile (Join-Path $modRoot "Launch Haven City Air Support.cmd") $cmd

  $summary = @"
$DisplayName $Version

Installed: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
OpenGOAL root: $($Target.OpenGoalRoot)
Jak II data: $($Target.DataPath)
Compiler: $($Target.CompilerPath)
Game executable: $($Target.GamePath)
Backup: $BackupRoot
Build log: $LogPath

This visible folder is the installed mod marker and launcher folder. The gameplay changes are patched into the Jak II data folder listed above.
"@
  Write-TextFile (Join-Path $modRoot "install-summary.txt") $summary

  return [PSCustomObject]@{
    ModFolder = $modRoot
    Launcher = $launcher
  }
}

function Invoke-ModInstallCore {
  param(
    [string]$SelectedPath,
    [string]$StatusPath
  )

  Write-InstallStatus $StatusPath "RUNNING" "Resolving OpenGOAL and Jak II paths..." $null
  $target = Resolve-InstallTarget $SelectedPath

  Write-InstallStatus $StatusPath "RUNNING" "Creating backup restore point..." @{
    DataPath = $target.DataPath
    CompilerPath = $target.CompilerPath
  }
  $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
  $backupRoot = Join-Path $target.DataPath "_mod_backups\$ModName\$stamp"
  New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

  $sourceFiles = @(
    "goal_src\jak2\levels\city\traffic\vehicle\vehicle-guard.gc",
    "goal_src\jak2\levels\city\traffic\traffic-manager.gc",
    "goal_src\jak2\levels\city\ctywide-obs.gc",
    "goal_src\jak2\dgos\lwideb.gd",
    "out\jak2\iso\CWI.DGO",
    "out\jak2\iso\LWIDEB.DGO"
  )

  foreach ($relative in $sourceFiles) {
    Backup-File $target.DataPath $backupRoot $relative
  }

  Write-InstallStatus $StatusPath "RUNNING" "Applying Haven City Air Support source patch..." @{
    Backup = $backupRoot
  }
  Apply-ModPatch $target.DataPath

  Write-InstallStatus $StatusPath "RUNNING" "Rebuilding Jak II with goalc. This can take several minutes..." @{
    Backup = $backupRoot
    BuildLog = (Join-Path $backupRoot "goalc-build.log")
  }
  $logPath = Invoke-GoalcRebuild $target.CompilerPath $target.DataPath $backupRoot

  Write-InstallStatus $StatusPath "RUNNING" "Creating launchers and visible installed mod folder..." @{
    Backup = $backupRoot
    BuildLog = $logPath
  }
  $launcherPath = Write-VbsLauncher $target.GamePath $target.DataPath
  $visibleInstall = Install-VisibleModFolder $target $backupRoot $logPath

  if (-not $launcherPath) {
    $launcherPath = "Could not create VBS launcher because gk.exe was not found beside goalc.exe. Launch through OpenGOAL Launcher instead."
  }

  $installedFolder = "Could not create visible mod folder because the OpenGOAL root was not detected."
  if ($visibleInstall) {
    $installedFolder = $visibleInstall.ModFolder
    if ($visibleInstall.Launcher) {
      $launcherPath = $visibleInstall.Launcher
    }
  }

  Write-InstallStatus $StatusPath "DONE" "$DisplayName installed successfully." @{
    InstalledFolder = $installedFolder
    Backup = $backupRoot
    BuildLog = $logPath
    Launcher = $launcherPath
  }

  return [PSCustomObject]@{
    InstalledFolder = $installedFolder
    Backup = $backupRoot
    BuildLog = $logPath
    Launcher = $launcherPath
  }
}

function Install-Mod {
  param([string]$SelectedPath)

  $target = Resolve-InstallTarget $SelectedPath
  $message = @"
Found Jak II data:
$($target.DataPath)

Found compiler:
$($target.CompilerPath)

The installer will:
- Back up the original source/output files
- Apply the $DisplayName source edits
- Rebuild Jak II with goalc
- Create a visible installed mod folder

Continue?
"@
  if (-not (Confirm-Action $message)) {
    return
  }

  $result = Invoke-ModInstallCore $SelectedPath $null

  Show-SuccessBox @"
$DisplayName was successfully installed.

You can now proceed with testing.

Installed mod folder:
$($result.InstalledFolder)

Backup:
$($result.Backup)

Build log:
$($result.BuildLog)

Launcher:
$($result.Launcher)

Load a late-game Haven City invasion save to test the mod.
"@
}

function Start-Wizard {
  $form = New-Object System.Windows.Forms.Form
  $form.Text = "$DisplayName Installer"
  $form.StartPosition = "CenterScreen"
  $form.Size = New-Object System.Drawing.Size(660, 360)
  $form.FormBorderStyle = "FixedDialog"
  $form.MaximizeBox = $false

  $title = New-Object System.Windows.Forms.Label
  $title.Text = "$DisplayName $Version"
  $title.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
  $title.AutoSize = $true
  $title.Location = New-Object System.Drawing.Point(18, 18)
  $form.Controls.Add($title)

  $description = New-Object System.Windows.Forms.Label
  $description.Text = "Choose your OpenGOAL or Jak II folder. The wizard will patch your local Jak II source, back it up, and rebuild it."
  $description.Font = New-Object System.Drawing.Font("Segoe UI", 9)
  $description.Size = New-Object System.Drawing.Size(600, 40)
  $description.Location = New-Object System.Drawing.Point(20, 56)
  $form.Controls.Add($description)

  $pathLabel = New-Object System.Windows.Forms.Label
  $pathLabel.Text = "OpenGOAL / Jak II directory"
  $pathLabel.AutoSize = $true
  $pathLabel.Location = New-Object System.Drawing.Point(20, 108)
  $form.Controls.Add($pathLabel)

  $pathBox = New-Object System.Windows.Forms.TextBox
  $pathBox.Location = New-Object System.Drawing.Point(22, 130)
  $pathBox.Size = New-Object System.Drawing.Size(500, 24)
  if (Test-Path -LiteralPath "D:\OpenGOAL") {
    $pathBox.Text = "D:\OpenGOAL"
  }
  $form.Controls.Add($pathBox)

  $browseButton = New-Object System.Windows.Forms.Button
  $browseButton.Text = "Browse..."
  $browseButton.Location = New-Object System.Drawing.Point(532, 128)
  $browseButton.Size = New-Object System.Drawing.Size(90, 28)
  $browseButton.Add_Click({
      $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
      $dialog.Description = "Choose your OpenGOAL folder, active\jak2 folder, or active\jak2\data folder."
      if ($pathBox.Text -and (Test-Path -LiteralPath $pathBox.Text)) {
        $dialog.SelectedPath = $pathBox.Text
      }
      if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
        $pathBox.Text = $dialog.SelectedPath
      }
    })
  $form.Controls.Add($browseButton)

  $note = New-Object System.Windows.Forms.Label
  $note.Text = "Most users should select the folder containing OpenGOAL-Launcher.exe. Rebuild time depends on your PC."
  $note.Font = New-Object System.Drawing.Font("Segoe UI", 8)
  $note.Size = New-Object System.Drawing.Size(600, 34)
  $note.Location = New-Object System.Drawing.Point(22, 164)
  $form.Controls.Add($note)

  $statusLabel = New-Object System.Windows.Forms.Label
  $statusLabel.Text = "Ready to install."
  $statusLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
  $statusLabel.Size = New-Object System.Drawing.Size(600, 34)
  $statusLabel.Location = New-Object System.Drawing.Point(22, 202)
  $form.Controls.Add($statusLabel)

  $progressBar = New-Object System.Windows.Forms.ProgressBar
  $progressBar.Location = New-Object System.Drawing.Point(22, 238)
  $progressBar.Size = New-Object System.Drawing.Size(600, 18)
  $progressBar.Style = "Blocks"
  $progressBar.Visible = $false
  $form.Controls.Add($progressBar)

  $installButton = New-Object System.Windows.Forms.Button
  $installButton.Text = "Install"
  $installButton.Location = New-Object System.Drawing.Point(430, 278)
  $installButton.Size = New-Object System.Drawing.Size(90, 30)

  $script:InstallProcess = $null
  $script:InstallStatusFile = $null
  $script:InstallCompleted = $false

  $timer = New-Object System.Windows.Forms.Timer
  $timer.Interval = 1000
  $timer.Add_Tick({
      try {
        $status = Read-InstallStatus $script:InstallStatusFile
        if ($status) {
          $statusLabel.Text = $status.Message
        }

        if ($script:InstallProcess -and $script:InstallProcess.HasExited) {
          $timer.Stop()
          $progressBar.Style = "Blocks"
          $progressBar.Value = 100
          $installButton.Enabled = $true
          $browseButton.Enabled = $true
          $cancelButton.Enabled = $true
          $script:InstallCompleted = $true

          if (-not $status) {
            Show-ErrorBox "Installer process exited without writing a status file."
            return
          }

          if ($status.State -eq "DONE") {
            $statusLabel.Text = "Installation complete. You can now test the mod."
            $message = @"
$DisplayName was successfully installed.

You can now proceed with testing.

Installed mod folder:
$($status.Details["InstalledFolder"])

Backup:
$($status.Details["Backup"])

Build log:
$($status.Details["BuildLog"])

Launcher:
$($status.Details["Launcher"])

Load a late-game Haven City invasion save to test the mod.
"@
            Show-SuccessBox $message
            $form.Close()
          }
          elseif ($status.State -eq "ERROR") {
            Show-ErrorBox $status.Message
          }
          else {
            Show-ErrorBox "Installer process exited before reporting success. Last status: $($status.Message)"
          }
        }
      }
      catch {
        $timer.Stop()
        $installButton.Enabled = $true
        $browseButton.Enabled = $true
        $cancelButton.Enabled = $true
        $progressBar.Style = "Blocks"
        Show-ErrorBox $_.Exception.Message
      }
    })

  $installButton.Add_Click({
      try {
        $target = Resolve-InstallTarget $pathBox.Text
        $message = @"
Found Jak II data:
$($target.DataPath)

Found compiler:
$($target.CompilerPath)

The installer will:
- Back up the original source/output files
- Apply the $DisplayName source edits
- Rebuild Jak II with goalc
- Create a visible installed mod folder

Continue?
"@
        if (-not (Confirm-Action $message)) {
          return
        }

        $installButton.Enabled = $false
        $browseButton.Enabled = $false
        $cancelButton.Enabled = $false
        $progressBar.Visible = $true
        $progressBar.Style = "Marquee"
        $statusLabel.Text = "Starting installer..."

        $script:InstallStatusFile = Join-Path ([System.IO.Path]::GetTempPath()) "$ModName-install-$PID-$(Get-Date -Format 'yyyyMMddHHmmss').status"
        Write-InstallStatus $script:InstallStatusFile "RUNNING" "Starting installer..." $null

        $argumentList = @(
          "-NoProfile",
          "-ExecutionPolicy",
          "Bypass",
          "-File",
          (Quote-ProcessArgument $InstallerScriptPath),
          "-RunInstallPath",
          (Quote-ProcessArgument $target.SelectedPath),
          "-StatusFile",
          (Quote-ProcessArgument $script:InstallStatusFile)
        ) -join " "

        $script:InstallProcess = Start-Process -FilePath "powershell.exe" -ArgumentList $argumentList -WindowStyle Hidden -PassThru
        $timer.Start()
      }
      catch {
        Show-ErrorBox $_.Exception.Message
        $installButton.Enabled = $true
        $browseButton.Enabled = $true
        $cancelButton.Enabled = $true
        $progressBar.Style = "Blocks"
      }
    })
  $form.Controls.Add($installButton)

  $cancelButton = New-Object System.Windows.Forms.Button
  $cancelButton.Text = "Cancel"
  $cancelButton.Location = New-Object System.Drawing.Point(532, 278)
  $cancelButton.Size = New-Object System.Drawing.Size(90, 30)
  $cancelButton.Add_Click({ $form.Close() })
  $form.Controls.Add($cancelButton)

  $form.Add_FormClosing({
      if ($script:InstallProcess -and -not $script:InstallProcess.HasExited -and -not $script:InstallCompleted) {
        $_.Cancel = $true
        Show-Info "Installation is still running. Please wait for it to finish."
      }
    })

  [void]$form.ShowDialog()
}

if ($SelfTest) {
  Write-Host "$DisplayName installer self-test loaded."
  exit 0
}

if ($ResolveOnlyPath) {
  $target = Resolve-InstallTarget $ResolveOnlyPath
  $target | ConvertTo-Json -Depth 3
  exit 0
}

if ($PatchOnlyDataPath) {
  if (-not (Test-Jak2DataPath $PatchOnlyDataPath)) {
    throw "PatchOnlyDataPath is not a valid Jak II data folder."
  }
  Apply-ModPatch $PatchOnlyDataPath
  Write-Host "$DisplayName patch-only test completed."
  exit 0
}

if ($RunInstallPath) {
  try {
    Invoke-ModInstallCore $RunInstallPath $StatusFile | Out-Null
    exit 0
  }
  catch {
    Write-InstallStatus $StatusFile "ERROR" $_.Exception.Message $null
    exit 1
  }
}

try {
  Start-Wizard
}
catch {
  Show-ErrorBox $_.Exception.Message
  exit 1
}
