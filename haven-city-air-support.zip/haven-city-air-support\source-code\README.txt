Haven City Air Support source code
==================================

This folder is included for Git hosting and review. It contains the source-level work used to build the distributable installer.

Contents
--------
- scripts
  Installer, launcher, save installer, and package assembly scripts.
- patches
  A unified GOAL patch showing the OpenGOAL Jak II source edits made by the mod.

Recommended install path
------------------------
Use the top-level "Install Haven City Air Support.cmd" installer for normal installation. The patch file is included so the source changes can be reviewed, audited, or ported manually by someone familiar with OpenGOAL.

The installer creates a backup before patching a local OpenGOAL Jak II install, then rebuilds Jak II with goalc.
