$ErrorActionPreference = "Stop"

$workspacePackage = Join-Path $PSScriptRoot "haven-city-air-support"
$desktop = [Environment]::GetFolderPath("Desktop")
$packageName = "haven-city-air-support"
$destination = Join-Path $desktop $packageName
$zipPath = Join-Path $desktop "$packageName.zip"

if (-not (Test-Path -LiteralPath $workspacePackage)) {
  throw "Package source folder not found: $workspacePackage"
}

$desktopFull = [System.IO.Path]::GetFullPath($desktop).TrimEnd('\') + '\'
$destinationFull = [System.IO.Path]::GetFullPath($destination)
$zipFull = [System.IO.Path]::GetFullPath($zipPath)

if (-not $destinationFull.StartsWith($desktopFull, [System.StringComparison]::OrdinalIgnoreCase)) {
  throw "Destination is outside the Desktop: $destinationFull"
}
if (-not $zipFull.StartsWith($desktopFull, [System.StringComparison]::OrdinalIgnoreCase)) {
  throw "Zip path is outside the Desktop: $zipFull"
}

New-Item -ItemType Directory -Force -Path $destination | Out-Null
$staleNested = Join-Path $destination $packageName
if (Test-Path -LiteralPath $staleNested) {
  $staleNestedFull = [System.IO.Path]::GetFullPath($staleNested)
  $destinationPrefix = [System.IO.Path]::GetFullPath($destination).TrimEnd('\') + '\'
  if (-not $staleNestedFull.StartsWith($destinationPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to remove unexpected nested path: $staleNestedFull"
  }
  try {
    Remove-Item -LiteralPath $staleNested -Recurse -Force
  }
  catch {
    Write-Warning "Could not remove stale nested package folder because it is in use: $staleNested"
  }
}

Copy-Item -LiteralPath (Join-Path $workspacePackage "readme.txt") -Destination $destination -Force
Copy-Item -LiteralPath (Join-Path $workspacePackage "Install Haven City Air Support.cmd") -Destination $destination -Force
Copy-Item -LiteralPath (Join-Path $workspacePackage "Install Included Invasion Save.cmd") -Destination $destination -Force
Copy-Item -LiteralPath (Join-Path $workspacePackage "Launch Haven City Air Support.vbs") -Destination $destination -Force
Copy-Item -LiteralPath (Join-Path $workspacePackage "install-wizard.ps1") -Destination $destination -Force
Copy-Item -LiteralPath (Join-Path $workspacePackage "install-included-saves.ps1") -Destination $destination -Force
Copy-Item -LiteralPath (Join-Path $workspacePackage "_metadata.json") -Destination $destination -Force

$sourceCodeSource = Join-Path $workspacePackage "source-code"
if (Test-Path -LiteralPath $sourceCodeSource) {
  $sourceCodeDestination = Join-Path $destination "source-code"
  if (Test-Path -LiteralPath $sourceCodeDestination) {
    Remove-Item -LiteralPath $sourceCodeDestination -Recurse -Force
  }
  Copy-Item -LiteralPath $sourceCodeSource -Destination $sourceCodeDestination -Recurse -Force
}

$savesSource = Join-Path $workspacePackage "personal-saves"
if (Test-Path -LiteralPath $savesSource) {
  $savesDestination = Join-Path $destination "personal-saves"
  if (Test-Path -LiteralPath $savesDestination) {
    Remove-Item -LiteralPath $savesDestination -Recurse -Force
  }
  Copy-Item -LiteralPath $savesSource -Destination $savesDestination -Recurse -Force
}

Compress-Archive -LiteralPath $workspacePackage -DestinationPath $zipPath -Force

Write-Host "Created folder: $destination"
Write-Host "Created zip: $zipPath"
Get-ChildItem -LiteralPath $destination -Force | Select-Object Mode,Length,LastWriteTime,Name
Get-Item -LiteralPath $zipPath | Select-Object FullName,Length,LastWriteTime
